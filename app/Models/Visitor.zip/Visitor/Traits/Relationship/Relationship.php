<?php

namespace App\Models\Visitor\Traits\Relationship;

/**
 * Class Relationship.
 */
trait Relationship
{

}
